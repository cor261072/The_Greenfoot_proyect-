
INSTRUCCIONES IMPORTANTES

1. Instalar Greenfoot.
2. Descomprimir el ZIP.
3. Abrir Greenfoot.
4. Click en:
   Project -> Open Project
5. Seleccionar la carpeta:
   Greenfoot_FIXED_Project
6. Abrir MenuWorld.
7. Presionar COMPILE.
8. Presionar RUN.

SI NO FUNCIONA:
- usar Greenfoot versión reciente
- asegurarse de abrir la carpeta completa
- no abrir solo los .java
